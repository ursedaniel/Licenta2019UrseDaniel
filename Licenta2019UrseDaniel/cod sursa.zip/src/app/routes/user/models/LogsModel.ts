export class LogsModel {
  dateStart: string;
  dateEnd: string;
  username1: string;
  username2: string;
  duration: string;
  price: string;
  constructor() {
  }
}


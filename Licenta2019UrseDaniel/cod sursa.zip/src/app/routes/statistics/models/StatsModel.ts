export class StatsModel {
  date: Date;
  username: string;
  profile: boolean;
  constructor() {
  }
}


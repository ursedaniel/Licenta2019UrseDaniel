export interface AuthDataModel {
  email?: string;
  username: string;
  password: string;
  type?: boolean;
  online?: boolean;
}

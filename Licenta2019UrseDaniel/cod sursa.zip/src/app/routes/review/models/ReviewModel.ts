export class ReviewModel {
  date: any;
  username1: string;
  username2: string;
  rating: number;
  review: string;
  logId: number;

  constructor() {

  }
}

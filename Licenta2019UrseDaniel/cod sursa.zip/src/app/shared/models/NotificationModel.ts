export class NotificationModel {
  date: Date;
  username: string;
  message: string;
  checked: boolean;
}

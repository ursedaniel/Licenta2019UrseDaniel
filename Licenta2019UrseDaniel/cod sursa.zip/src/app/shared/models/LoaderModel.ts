export class LoaderModel{
  constructor(
    public show:boolean,
    public htmlElement:HTMLElement
  ){}
}
